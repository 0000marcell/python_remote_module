from setuptools import setup, find_packages

setup(
    name='python_remote_module',
    version='1.0.0',
    author='Marcell Cruz',
    author_email='',
    description='Description of your package',
    packages=find_packages(),
    install_requires=[],
)
